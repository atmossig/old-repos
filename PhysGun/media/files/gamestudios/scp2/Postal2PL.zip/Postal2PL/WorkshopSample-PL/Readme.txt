Note: When compiling code for Paradise Lost, the usual steps apply.

Note that you will need a Postal2.ini because the ucc script compiler looks for Postal2.ini, not ParadiseLost.ini. Just run "ucc make" once to generate it, then add in your code package.

Just an FYI from your friendly neighborhood coder :)
